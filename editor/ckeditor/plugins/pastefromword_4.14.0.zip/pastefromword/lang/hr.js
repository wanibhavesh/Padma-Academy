/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'hr', {
	confirmCleanup: 'Tekst koji želite zalijepiti čini se da je kopiran iz Worda. Želite li prije očistiti tekst?',
	error: 'Nije moguće očistiti podatke za ljepljenje zbog interne greške',
	title: 'Zalijepi iz Worda',
	toolbar: 'Zalijepi iz Worda'
} );
