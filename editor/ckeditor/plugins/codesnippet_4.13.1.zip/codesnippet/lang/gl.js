/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'codesnippet', 'gl', {
	button: 'Inserir fragmento de código',
	codeContents: 'Contido do código',
	emptySnippetError: 'Un fragmento de código non pode estar baleiro.',
	language: 'Linguaxe',
	title: 'Fragmento de código',
	pathName: 'fragmento de código'
} );
